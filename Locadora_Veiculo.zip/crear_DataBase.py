from app import DataBase
from app.models import User
from app import app


with app.app_context():
    DataBase.create_all()
    print("Banco de datos creado perfectamente")