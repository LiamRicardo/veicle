from flask import Flask
from flask import Blueprint,render_template


main = Blueprint('main' , __name__)





@main.route('/')
@main.route('/menu')
def inicial():
    return render_template('index.html')





@main.route('/veiculos')
def veiculos():
    return render_template('veiculos.html')






@main.route('/formularios')
def formu():
    return render_template('fomularios.html')