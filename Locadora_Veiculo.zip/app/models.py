from . import DataBase




class User(DataBase.Model):
    __tablename__ = 'Usuarios'
    
    id = DataBase.Column(DataBase.Integer,unique=True ,primary_key=True)
    Usuario = DataBase.Column(DataBase.String(80) , nullable=False)
    Contraseña = DataBase.Column(DataBase.String(100) , nullable=False)
    CPF = DataBase.Column(DataBase.Float, nullable=False)
    
    def __repr__(self):
        return f'<User {self.Usuario}>'
